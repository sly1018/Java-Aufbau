package mitarbeiterVerwaltung2;

import java.time.LocalDate;

public class MitarbeiterInterfaceProgramm {

	private static MitarbeiterListeItf gruppe1 = new MitarbeiterListe();

	public static void main(String[] args) {
		gruppe1.mitarbeiterHinzufuegen(
				new Mitarbeiter("Roman", LocalDate.of(1978, 6, 24), LocalDate.of(2004, 8, 13), 3000));
		gruppe1.anzeigen(1);
		
		gruppe1.managerHinzufuegen("Ana", LocalDate.of(1989, 2, 12), LocalDate.of(2009, 7, 21), 3000, 1000);
		gruppe1.anzeigen(2);
		
		gruppe1.experteHinzufuegen("Herbert",LocalDate.of(1998, 6, 1), "Orthopäde");
		gruppe1.anzeigen(3);
		
		System.out.println();
		System.out.println("Gehalt für alle Mitarbeiter-Objekte erhöhen und anzeigen.");
		gruppe1.erhoehung(1.13f);
		gruppe1.anzeigen(1);
		gruppe1.anzeigen(2);
		gruppe1.anzeigen(3);
		
		System.out.println();
		System.out.println("Gehalt und Bonus für Mitarbeiter 2 erhöhen und anzeigen.");
		
		gruppe1.erhoehung(2, 1.13f);
		gruppe1.anzeigen(2);
		
		System.out.println();
		System.out.println("Sortiert nach Name anzeigen:");
		gruppe1.sortiertNachName();
		
		System.out.println();
		System.out.println("Sortiert nach Typ und Eintrittsdatum anzeigen:");
		gruppe1.sortiertNachTyp();
		
		System.out.println();
		System.out.println("Mitarbeiter 3 löschen und alle anzeigen:");
		gruppe1.abmelden(3);
		gruppe1.sortiertNachName();
	}

}
