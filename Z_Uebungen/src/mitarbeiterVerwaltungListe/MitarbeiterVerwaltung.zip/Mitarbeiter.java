package mitarbeiterVerwaltung;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class Mitarbeiter {

	private static int zaehler;

	private final int mitarbeiterId;
	private String name;
	private LocalDate gbDatum;
	private LocalDate eintrittsDatum;
	private double grundgehalt;

	static {
		zaehler = 1;
	}

	public Mitarbeiter() {
		this.mitarbeiterId = zaehler++;
	}

	public double getGrundgehalt() {
		return grundgehalt;
	}

	public String getName() {
		return name;
	}

	public Mitarbeiter(String n, LocalDate gb, LocalDate ed, double gg) {
		this.mitarbeiterId = zaehler++;
		this.name = n;
		this.gbDatum = gb;
		this.eintrittsDatum = ed;
		this.grundgehalt = gg;
	}

	public double berechneMonatsGehalt() {
		return grundgehalt;
	}

	public double berechneJahresGehalt() {
		return (grundgehalt * 14);
	}

	public void erhoeheGehalt(float prozentsatz) {
		grundgehalt = grundgehalt * prozentsatz;
	}

	public long berechneAnstellungsDauer() {
		LocalDate heute = LocalDate.now();
		long rueWert = ChronoUnit.DAYS.between(eintrittsDatum, heute);
		return rueWert;
	}

	public String holeMitarbeiterInfo() {
		return "[Mitarbeiter Id: %d], [Name: %s], [Geburtsdatum: %s], [Eintrittsdatum: %s], [Grundgehalt: %.2f]"
				.formatted(mitarbeiterId, name, gbDatum, eintrittsDatum, grundgehalt);
	}

}
