package calc3;

public class CalcMain {

	public static void main(String[] args) {
		//new CalculatorFrame().setVisible(true);
		new CalcRaster().setVisible(true);
	}

}