package calc;

public class CalcMain {

	public static void main(String[] args) {
		new CalculatorFrame().setVisible(true);
	}

}