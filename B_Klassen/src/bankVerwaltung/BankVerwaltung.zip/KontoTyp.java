package bankVerwaltung;

public enum KontoTyp {
	
	SPARBUCH, GEHALTSKONTO;

}
